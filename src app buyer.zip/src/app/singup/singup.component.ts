import { Component, OnInit } from '@angular/core';
import { Buyer } from '../Buyer';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-singup',
  templateUrl: './singup.component.html',
  styleUrls: ['./singup.component.css']
})
export class SingupComponent implements OnInit {

  constructor(private buyerservice:BuyerService ) { }

  buyer:Buyer =new Buyer();

  ngOnInit(): void {
  }

  
  addbuyer()
  {
    console.log("buyyer");
    console.log(this.buyer);
    this.buyerservice.createBuyer(this.buyer).subscribe(buyer=>{alert("your details are saved successfully .")})
  }

  onSubmit()
  {
    this.addbuyer();
  }

}
