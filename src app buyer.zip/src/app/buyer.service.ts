import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Buyer } from './Buyer';
import { Observable } from 'rxjs';
import { TransactionEntity } from './transaction';
import { ApiResponse } from './model/api.response';

@Injectable({
  providedIn: 'root'
})
export class BuyerService {

  private baseUrl='http://localhost:8918/api1/Buyer'
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8918/' + 'token/generate-token', loginPayload);
  }
  constructor( private http:HttpClient) { }
  

  createBuyer(buyer:Buyer) :Observable<any>
  {
    console.log("createBuyer");
    console.log(buyer.address);
  return this.http.post(`${this.baseUrl}`,buyer)

  }
 checkout(id:number,transaction:TransactionEntity):Observable<any>
 {


   console.log("servicechecout"+id);
   console.log(transaction);
   return this.http.post(`http://localhost:8918/api/checkout/${id}`,transaction);
 }
}
