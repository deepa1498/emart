import { Component, OnInit, Input } from '@angular/core';
import { Item } from '../Item';
import { Cart } from '../Cart';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  constructor(private service:ProductService) { }

  itemquantity:number=1;
  @Input() item:Item;
  cart:Cart = new Cart();
  ngOnInit(): void {
  }

  onSave(itemid:number)
  {
  console.log("onsave");
    this.cart.itemId=this.item.itemid;
    this.cart.price=this.item.itemCost;
    this.cart.description=this.item.itemName;
    this.cart.noOfItems=this.itemquantity
 this.service.addTocart(this.cart).subscribe(cart=> this.cart=cart);

  }
}
