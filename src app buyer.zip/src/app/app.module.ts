import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { SearchProductComponent } from './search-product/search-product.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { SingupComponent } from './singup/singup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { CardComponent } from './card/card.component';
import { TransactionComponent } from './transaction/transaction.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginformComponent } from './loginform/loginform.component';
import { ProductService } from './product.service';
import { TokenInterceptor } from './core/interceptor';

@NgModule({
  declarations: [
    AppComponent,
    ProductDetailsComponent,
    SearchProductComponent,
    DisplayCartComponent,
    SingupComponent,
    HomepageComponent,
    CardComponent,
    TransactionComponent,
  
    NavbarComponent,
    LoginformComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: 
    [ProductService,{provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi : true}],
    bootstrap: [AppComponent]})
 

export class AppModule { }
