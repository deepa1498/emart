export class Buyer
{
userName:string;
password:string;
email:string;
mobileNumber:number;
address:string;
}