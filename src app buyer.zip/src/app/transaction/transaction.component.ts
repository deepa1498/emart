import { Component, OnInit } from '@angular/core';
import { TransactionEntity, TransactionEntity1 } from '../transaction';
import { BuyerService } from '../buyer.service';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

id=1;
transactionreturn:TransactionEntity;
transaction:TransactionEntity=new TransactionEntity();

  constructor(private buyerservice:BuyerService) { }

  ngOnInit(): void {
  }
  
  chekoutit()
  {
    console.log("checout"+this.transaction);
    this.buyerservice.checkout(this.id,this.transaction).subscribe(transaction=>this.transaction=transaction);
  }

  onSubmit()
  {

   this.chekoutit();
 
}
}
