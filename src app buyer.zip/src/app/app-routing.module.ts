import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { SearchProductComponent } from './search-product/search-product.component';
import { DisplayCartComponent } from './display-cart/display-cart.component';
import { SingupComponent } from './singup/singup.component';
import { HomepageComponent } from './homepage/homepage.component';
import { CardComponent } from './card/card.component';
import { TransactionComponent } from './transaction/transaction.component';
import { LoginformComponent } from './loginform/loginform.component';


const routes: Routes = [
  {path:'product-details',component:ProductDetailsComponent  },
  {path:'search-details', component:SearchProductComponent},
  {path:'display-cart',component:DisplayCartComponent},
  {path:'singup',component:SingupComponent},
  {path:'homepage',component:HomepageComponent},
  {path:'card/:id',component:CardComponent},
  {path:'gototransaction',component:TransactionComponent},
  {path:'login-form',component:LoginformComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
