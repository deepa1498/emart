import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { Cart } from './Cart';
import { ViewCart } from './ViewCart';
import { $ } from 'protractor';
import { ApiResponse } from './model/api.response';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  


  private baseUrl = 'http://localhost:8919/itemapi/getallbyname';
  private baseUrl1 = 'http://localhost:8918/api/1/getall';

  constructor(private http:HttpClient) { }

  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8918/' + 'token/generate-token', loginPayload);
  }

addTocart(cart:Cart): Observable<any>
{
  return this.http.post(`http://localhost:8918/api/additem/1`,cart);
}
 

getItem(searchstr:string) : Observable<any>
{

  return this.http.get(`${this.baseUrl}/${searchstr}`);
}
getcartitems():Observable<any>
  {   
    
      console.log("in service method");
      return this.http.get(`${this.baseUrl1}`);
  }
  


  updateCartItem(view:ViewCart):Observable<any>
  {
    console.log(view);
    return this.http.put(`http://localhost:8918/api/update`,view);
  }
  deletecartitem(i:number) :Observable<any>
  {
    console.log("service method"+i);
  return  this.http.delete(`http://localhost:8918/api/deleteitem/${i}`);
  }

  getitembysubcatagory(id:number):Observable<any>
  {
   return  this.http.get(`http://localhost:8918/itemapi/getbysubid/${id}`);
  }
  getitembyid(id:number) :Observable<any>
  {
    return this.http.get(`http://localhost:8918/itemapi/item/${id}`)

  }
  
}



