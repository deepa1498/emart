import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Item } from '../Item';
import { Router, ActivatedRoute } from '@angular/router';
import { Cart } from '../Cart';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  constructor(private dataservice:ProductService,private router: Router,private route: ActivatedRoute) { }
item:Item = new Item();
id:number;
cart:Cart = new Cart();
itemquantity:number=1;
// receiveMessage($event: number) {
//   this.id = $event
// }


  ngOnInit(): void {
  
    this.id = this.route.snapshot.params['id'];

    this.dataservice.getitembyid(this.id).subscribe(item=>{
              console.log(item)
              this.item=item;
            }, error => console.log(error));
             
  }
insertintocart(id1:number)
{
  console.log("insertintocart");
  this.cart.itemId=this.item.itemid;
  this.cart.price=this.item.itemCost;
  this.cart.description=this.item.itemName;
  this.cart.noOfItems=this.itemquantity
this.dataservice.addTocart(this.cart).subscribe(cart=>{alert("item added Successfully To the Cart.") 
                                                         this.cart=cart});

}
  

  

}
